const NOTES_HEADER_MARKER = "# AEONTHRA Notes";

export type NotesFileMetadata = {
  title: string;
  subtitle?: string;
  savedAt: string;
};

function escapeForTxt(value: string): string {
  return value.replace(/\r\n?/g, "\n").trim();
}

function buildHeader(meta: NotesFileMetadata): string {
  const parts = [
    NOTES_HEADER_MARKER,
    meta.title ? `Title: ${meta.title}` : null,
    meta.subtitle ? `Subtitle: ${meta.subtitle}` : null,
    `Saved: ${meta.savedAt}`,
    ""
  ].filter((entry): entry is string => entry !== null);
  return parts.join("\n");
}

export function formatNotesForFile(notes: string, meta: NotesFileMetadata): string {
  return `${buildHeader(meta)}\n${escapeForTxt(notes)}\n`;
}

export function stripNotesHeader(contents: string): string {
  const text = contents.replace(/\r\n?/g, "\n");
  if (!text.startsWith(NOTES_HEADER_MARKER)) {
    return text.trim();
  }
  const firstBlankIndex = text.indexOf("\n\n");
  if (firstBlankIndex < 0) {
    return "";
  }
  return text.slice(firstBlankIndex + 2).trim();
}

export function safeFileNameStem(value: string): string {
  return value
    .replace(/[\\/:*?"<>|]/g, "-")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/(^-+|-+$)/g, "")
    .slice(0, 80)
    || "aeonthra-notes";
}

function supportsFsAccess(): boolean {
  return typeof window !== "undefined" && typeof (window as unknown as { showSaveFilePicker?: unknown }).showSaveFilePicker === "function";
}

export async function saveNotesAsTxt(
  notes: string,
  meta: NotesFileMetadata,
  options: { preferredName?: string } = {}
): Promise<{ ok: true; via: "fs-access" | "download" } | { ok: false; error: string }> {
  try {
    const body = formatNotesForFile(notes, meta);
    const suggestedName = `${safeFileNameStem(options.preferredName ?? meta.title)}.txt`;
    if (supportsFsAccess()) {
      const picker = (window as unknown as {
        showSaveFilePicker: (init: unknown) => Promise<unknown>;
      }).showSaveFilePicker;
      const handle = await picker({
        suggestedName,
        types: [
          {
            description: "Plain text",
            accept: { "text/plain": [".txt"] }
          }
        ]
      }) as { createWritable: () => Promise<{ write: (chunk: string) => Promise<void>; close: () => Promise<void> }> };
      const writable = await handle.createWritable();
      await writable.write(body);
      await writable.close();
      return { ok: true, via: "fs-access" };
    }

    const blob = new Blob([body], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = suggestedName;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    return { ok: true, via: "download" };
  } catch (error) {
    if (error && typeof error === "object" && "name" in error && (error as { name: string }).name === "AbortError") {
      return { ok: false, error: "Cancelled" };
    }
    return {
      ok: false,
      error: error instanceof Error ? error.message : "Could not save notes."
    };
  }
}

export type LearningResultInput = {
  conceptId: string;
  conceptName: string;
  mastery: number;
  memoryStage?: string;
  missedTrap?: string | null;
};

export type LearningResultsSummaryInput = {
  courseName: string;
  totalAnswered: number;
  totalCorrect: number;
  streak: number;
  bestStreak: number;
  sessionScore: { c: number; w: number };
  concepts: LearningResultInput[];
  ghosts?: Array<{ conceptName: string; text?: string; missedAt?: number }>;
};

export function buildLearningResultsSummary(input: LearningResultsSummaryInput): string {
  const ratio = input.totalAnswered > 0
    ? `${Math.round((input.totalCorrect / input.totalAnswered) * 100)}%`
    : "n/a";
  const mastered = input.concepts.filter((concept) => concept.mastery >= 0.8).length;
  const total = input.concepts.length;
  const headerLines: string[] = [
    `Course: ${input.courseName || "(unnamed)"}`,
    `Captured: ${new Date().toISOString()}`,
    `Concepts mastered: ${mastered}/${total}`,
    `Questions answered: ${input.totalAnswered} (correct ${input.totalCorrect}, ratio ${ratio})`,
    `Session score: ${input.sessionScore.c} correct / ${input.sessionScore.w} missed`,
    `Streak: ${input.streak} (best ${input.bestStreak})`,
    ""
  ];

  const conceptLines = input.concepts
    .slice()
    .sort((left, right) => right.mastery - left.mastery)
    .map((concept) => {
      const masteryPct = `${Math.round(concept.mastery * 100)}%`.padStart(4, " ");
      const stage = concept.memoryStage ? ` [${concept.memoryStage}]` : "";
      return `- ${masteryPct}  ${concept.conceptName}${stage}`;
    });

  const ghostLines = (input.ghosts ?? []).slice(-20).map((ghost) => {
    const when = ghost.missedAt ? new Date(ghost.missedAt).toISOString() : "";
    const text = ghost.text ? ` — ${ghost.text}` : "";
    return `- ${ghost.conceptName}${when ? ` (${when})` : ""}${text}`;
  });

  const sections = [
    "## Concepts",
    ...conceptLines,
    ""
  ];

  if (ghostLines.length > 0) {
    sections.push("## Recent Missed Concepts", ...ghostLines, "");
  }

  return [
    ...headerLines,
    ...sections
  ].join("\n");
}

export async function loadNotesFromTxt(): Promise<{ ok: true; text: string; fileName: string } | { ok: false; error: string }> {
  try {
    if (supportsFsAccess()) {
      const picker = (window as unknown as {
        showOpenFilePicker: (init: unknown) => Promise<Array<{ getFile: () => Promise<File> }>>;
      }).showOpenFilePicker;
      const [handle] = await picker({
        multiple: false,
        types: [
          {
            description: "Plain text",
            accept: { "text/plain": [".txt", ".md"] }
          }
        ]
      });
      if (!handle) {
        return { ok: false, error: "No file selected." };
      }
      const file = await handle.getFile();
      const text = await file.text();
      return { ok: true, text: stripNotesHeader(text), fileName: file.name };
    }

    return new Promise((resolve) => {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = ".txt,.md,text/plain";
      input.onchange = async () => {
        const file = input.files?.[0];
        if (!file) {
          resolve({ ok: false, error: "No file selected." });
          return;
        }
        const text = await file.text();
        resolve({ ok: true, text: stripNotesHeader(text), fileName: file.name });
      };
      input.click();
    });
  } catch (error) {
    if (error && typeof error === "object" && "name" in error && (error as { name: string }).name === "AbortError") {
      return { ok: false, error: "Cancelled" };
    }
    return {
      ok: false,
      error: error instanceof Error ? error.message : "Could not load notes."
    };
  }
}
