# AEONTHRA v2 — Build Notes

Built on the `xenodochial-agnesi-267bc8` worktree. What's new in this pass:

## Features Added

### 1. Deterministic semantic engine — harder, broader
- Kept the v2 truth gates (no fallback fabrication, provenance-backed admission).
- **Noun-phrase candidates with TF-IDF scoring** — `packages/content-engine-v2/src/candidates/noun-phrases.ts`. Repeated, heading-supported noun phrases are now admitted as concepts even without explicit "X is Y" sentences, as long as they pass the label gate and find at least one academic-signal support unit.
- **Explicit "noun-phrase-insufficient-support" rejection code** when phrases can't earn a definition lane.
- **Textbook cross-linking** — `packages/content-engine-v2/src/compatibility/legacy-projection.ts`. For each Canvas assignment, the top textbook segments (ranked by shared meaningful-token overlap) are appended to the assignment summary and checklist.

### 2. Per-page manual JSON capture
- Click the extension popup ⇒ **DOWNLOAD PAGE AS JSON (INSPECT)**.
- Saves a JSON dump of the current page's extracted structure (headings, paragraphs, list items, tables, raw HTML) for inspection or debugging. Works on any URL (not just Canvas) via `activeTab` permission.

### 3. Generic-webpage capture
- Click the extension popup ⇒ **SAVE AEONTHRA CAPTURE BUNDLE**.
- Produces a schema-valid `CaptureBundle` tagged `generic-page` that AEONTHRA will accept via its existing **CHOOSE CANVAS JSON** import.
- Bundle supports the full synthesis pipeline — concepts, assignments-of-sorts, atlas, practice, etc.

### 4. Textbook is now optional
- **CONTINUE WITHOUT TEXTBOOK** button in STEP 2 of the intake.
- Synthesis runs on just Canvas (or just a generic capture) and the shell renders.
- An "EXTRA SOURCES" panel lets you paste additional notes / links / raw text that gets folded into synthesis as extra textbook segments — use this anywhere, for any class.

### 5. Local .txt note system
- Settings view ⇒ **⬇ Save as .txt**, **⬆ Load from .txt**, **📊 Export Learning Results**.
- Prefers the File System Access API (Chromium) for "save to chosen folder", falls back to browser downloads elsewhere.
- Learning Results export writes a per-concept mastery summary, session score, streak, and recent missed concepts.

## Files Changed / Added

```
apps/web/src/App.tsx                                         # optional textbook, extras, generic bundle
apps/web/src/AeonthraShell.tsx                               # notes .txt buttons + TDZ bug fix
apps/web/src/lib/notes-export.ts                             # NEW: .txt save/load + results summary
apps/web/src/lib/source-workspace.ts                         # skipTextbookGate param + copy
apps/web/src/lib/source-workspace.test.ts                    # updated copy expectation
apps/extension/src/page-extractor.ts                         # NEW: self-contained page extractor
apps/extension/src/service-worker.ts                         # page capture + bundle download handlers
apps/extension/src/popup.tsx                                 # any-page capture UI
packages/content-engine-v2/src/candidates/noun-phrases.ts    # NEW: TF-IDF noun-phrase extractor
packages/content-engine-v2/src/candidates/concepts.ts        # integrate noun-phrase candidates
packages/content-engine-v2/src/compatibility/legacy-projection.ts   # textbook cross-linking
```

## How to Run

### Web app
```bash
npm install
npm run dev:web     # Vite on http://localhost:5176
npm run build:web   # production build to apps/web/dist
```

### Extension
```bash
npm run build:extension
# Chrome → chrome://extensions → Developer mode ON → Load unpacked → select apps/extension/dist
```

### Tests
```bash
npm test            # all workspaces
npm run typecheck   # tsc --noEmit
```

## Honest Caveats

- The shell (`AeonthraShell.tsx`) is still a 1950-line `@ts-nocheck` monolith. I fixed the one TDZ bug that blocked the no-textbook path but did not decompose it.
- Textbook cross-linking writes into `summary` and `checklist` because the schema lacks a dedicated link field. Longer term, add a first-class `textbookLinks: Array<{ title; excerpt; sourceItemId }>` to `AssignmentIntelligence`.
- Noun-phrase extraction is conservative (min 2 mentions, must pass label gate, must find definition-like or heading support). Tune `minMentions` / `minDocuments` in `noun-phrases.ts` if your corpora need more.
- Generic-page bundles bypass `inspectCanvasCourseKnowledgePack` via the `generic-page` tag. Canvas bundles still go through full identity validation.
- All tests pass (87 web + 43 extension + 15 content-engine-v2 + 4 interactions-engine = 149 total).
