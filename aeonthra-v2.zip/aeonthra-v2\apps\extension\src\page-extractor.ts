export type ExtractedBlock = {
  kind: "heading" | "paragraph" | "list-item" | "quote" | "code" | "table-row" | "caption";
  text: string;
  level?: number;
  headingTrail: string[];
};

export type ExtractedPage = {
  url: string;
  title: string;
  capturedAt: string;
  hostname: string;
  lang: string;
  description: string;
  author: string;
  headings: Array<{ level: number; text: string }>;
  blocks: ExtractedBlock[];
  plainText: string;
  excerpt: string;
  rawHtmlByteLength: number;
  rawHtml?: string;
};

export type PageExtractionOptions = {
  includeRawHtml?: boolean;
  maxPlainText?: number;
};

export const DEFAULT_MAX_PLAIN_TEXT = 200_000;

// Self-contained script string so we can inject into any tab via
// chrome.scripting.executeScript without having a content script bundle.
// This runs in the target page's isolated world.
export function extractCurrentPage(options: PageExtractionOptions = {}): ExtractedPage {
  const includeRawHtml = options.includeRawHtml === true;
  const maxPlainText = options.maxPlainText ?? DEFAULT_MAX_PLAIN_TEXT;

  const NOISE_SELECTORS = [
    "script",
    "style",
    "noscript",
    "iframe",
    "svg",
    "nav",
    "header",
    "footer",
    "aside",
    "form",
    "[role='navigation']",
    "[role='banner']",
    "[role='contentinfo']",
    "[role='search']",
    "[aria-hidden='true']",
    "[hidden]",
    ".sr-only",
    ".screenreader-only",
    ".visually-hidden"
  ];

  const normalizeWhitespace = (value: string): string =>
    value.replace(/\u00a0/g, " ").replace(/[\t\f\v ]+/g, " ").replace(/\s*\n\s*/g, "\n").replace(/\n{3,}/g, "\n\n").trim();

  const getTrimmedText = (element: Element): string => normalizeWhitespace(element.textContent ?? "");

  const pickMainContainer = (): Element => {
    const candidates = [
      document.querySelector("main"),
      document.querySelector("article"),
      document.querySelector("[role='main']"),
      document.querySelector("#content"),
      document.querySelector("#main"),
      document.querySelector("#primary"),
      document.querySelector(".content"),
      document.querySelector(".main"),
      document.querySelector(".article"),
      document.querySelector(".post"),
      document.body
    ].filter((entry): entry is Element => entry instanceof Element);
    return candidates[0] ?? document.documentElement;
  };

  const getMetaContent = (name: string): string => {
    const attribute = document.querySelector(`meta[name="${name}"], meta[property="${name}"]`);
    return attribute?.getAttribute("content")?.trim() ?? "";
  };

  const cloneWithoutNoise = (root: Element): Element => {
    const clone = root.cloneNode(true) as Element;
    NOISE_SELECTORS.forEach((selector) => {
      clone.querySelectorAll(selector).forEach((node) => node.remove());
    });
    return clone;
  };

  const headingLevel = (tag: string): number | null => {
    const match = /^h([1-6])$/i.exec(tag);
    return match ? Number(match[1]) : null;
  };

  const headingTrail: string[] = [];
  const headings: Array<{ level: number; text: string }> = [];
  const blocks: ExtractedBlock[] = [];

  const mainContainer = pickMainContainer();
  const cleanedMain = cloneWithoutNoise(mainContainer);

  const visit = (element: Element) => {
    const tag = element.tagName.toLowerCase();
    const headingLvl = headingLevel(tag);

    if (headingLvl !== null) {
      const text = getTrimmedText(element);
      if (text && text.length <= 220) {
        while (headingTrail.length >= headingLvl) {
          headingTrail.pop();
        }
        headingTrail.push(text);
        headings.push({ level: headingLvl, text });
        blocks.push({ kind: "heading", level: headingLvl, text, headingTrail: [...headingTrail] });
      }
      return;
    }

    if (tag === "p") {
      const text = getTrimmedText(element);
      if (text && text.length >= 3) {
        blocks.push({ kind: "paragraph", text, headingTrail: [...headingTrail] });
      }
      return;
    }

    if (tag === "li") {
      const text = getTrimmedText(element);
      if (text && text.length >= 3) {
        blocks.push({ kind: "list-item", text, headingTrail: [...headingTrail] });
      }
      return;
    }

    if (tag === "blockquote") {
      const text = getTrimmedText(element);
      if (text && text.length >= 3) {
        blocks.push({ kind: "quote", text, headingTrail: [...headingTrail] });
      }
      return;
    }

    if (tag === "pre") {
      const text = getTrimmedText(element);
      if (text && text.length >= 3) {
        blocks.push({ kind: "code", text, headingTrail: [...headingTrail] });
      }
      return;
    }

    if (tag === "tr") {
      const cellTexts = Array.from(element.children)
        .map((cell) => normalizeWhitespace(cell.textContent ?? ""))
        .filter((text) => text.length > 0);
      if (cellTexts.length > 0) {
        blocks.push({ kind: "table-row", text: cellTexts.join(" | "), headingTrail: [...headingTrail] });
      }
      return;
    }

    if (tag === "figcaption" || tag === "caption") {
      const text = getTrimmedText(element);
      if (text) {
        blocks.push({ kind: "caption", text, headingTrail: [...headingTrail] });
      }
      return;
    }

    Array.from(element.children).forEach((child) => {
      if (child instanceof Element) {
        visit(child);
      }
    });
  };

  Array.from(cleanedMain.children).forEach((child) => {
    if (child instanceof Element) {
      visit(child);
    }
  });

  const seen = new Set<string>();
  const dedupedBlocks = blocks.filter((block) => {
    const key = `${block.kind}:${block.text}`;
    if (seen.has(key)) {
      return false;
    }
    seen.add(key);
    return true;
  });

  const title = document.title?.trim() || document.querySelector("h1")?.textContent?.trim() || window.location.pathname;
  const plainTextFull = dedupedBlocks
    .map((block) => (block.kind === "heading" ? `# ${block.text}` : block.text))
    .join("\n\n");
  const plainText = plainTextFull.length > maxPlainText
    ? `${plainTextFull.slice(0, maxPlainText)}\n\n[… truncated at ${maxPlainText.toLocaleString()} characters …]`
    : plainTextFull;

  const excerpt = plainText.split(/\n+/).find((line) => line.length >= 80 && line.length <= 320)
    ?? plainText.slice(0, 280);

  return {
    url: window.location.href,
    title: normalizeWhitespace(title),
    capturedAt: new Date().toISOString(),
    hostname: window.location.hostname,
    lang: document.documentElement.lang || "",
    description: getMetaContent("description") || getMetaContent("og:description"),
    author: getMetaContent("author") || getMetaContent("article:author"),
    headings,
    blocks: dedupedBlocks,
    plainText,
    excerpt: normalizeWhitespace(excerpt),
    rawHtmlByteLength: document.documentElement.outerHTML.length,
    rawHtml: includeRawHtml ? document.documentElement.outerHTML : undefined
  };
}
