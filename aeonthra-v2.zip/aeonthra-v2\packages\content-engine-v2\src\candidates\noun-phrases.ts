import type { EvidenceUnit } from "../contracts/types.ts";
import { evaluateLabel } from "../truth-gates/labels.ts";
import { isGenericTitleContainerText, isGenericWrapperLabel } from "../noise/rules.ts";
import { meaningfulTokens, normalizeForCompare } from "../utils/text.ts";

export type NounPhraseCandidate = {
  label: string;
  normalizedLabel: string;
  keywords: string[];
  totalMentions: number;
  documentIds: Set<string>;
  evidenceIds: Set<string>;
  headingSupport: boolean;
  tfIdfScore: number;
};

const MAX_PHRASE_TOKENS = 6;
const MIN_PHRASE_TOKENS = 2;
const MIN_TOTAL_MENTIONS = 2;
const MIN_DOCUMENT_COUNT = 1;

const CAPITAL_PHRASE_PATTERN =
  /(?:[A-Z][A-Za-z][A-Za-z0-9'/-]*)(?:\s+(?:of|and|or|in|on|for|to|the|a|an|as|with|by|from|vs\.?))*(?:\s+[A-Z][A-Za-z][A-Za-z0-9'/-]*){0,4}/g;

const QUOTED_PHRASE_PATTERN = /"([^"\n]{4,80})"|\u201C([^\u201D\n]{4,80})\u201D/g;

const TITLE_CASE_SEQUENCE_PATTERN =
  /\b([A-Z][A-Za-z][A-Za-z0-9'/-]*(?:\s+[A-Z][A-Za-z][A-Za-z0-9'/-]*){1,5})\b/g;

const CONNECTOR_STOP_TOKENS = new Set([
  "of",
  "and",
  "or",
  "in",
  "on",
  "for",
  "to",
  "the",
  "a",
  "an",
  "as",
  "with",
  "by",
  "from"
]);

function trimConnectorEdges(phrase: string): string {
  const tokens = phrase.split(/\s+/).filter(Boolean);
  while (tokens.length > 0 && CONNECTOR_STOP_TOKENS.has(tokens[0]!.toLowerCase())) {
    tokens.shift();
  }
  while (tokens.length > 0 && CONNECTOR_STOP_TOKENS.has(tokens[tokens.length - 1]!.toLowerCase())) {
    tokens.pop();
  }
  return tokens.join(" ");
}

function acceptablePhrase(phrase: string): boolean {
  const trimmed = phrase.trim();
  if (!trimmed) {
    return false;
  }
  const tokens = trimmed.split(/\s+/);
  if (tokens.length < MIN_PHRASE_TOKENS || tokens.length > MAX_PHRASE_TOKENS) {
    return false;
  }
  if (isGenericTitleContainerText(trimmed) || isGenericWrapperLabel(trimmed)) {
    return false;
  }
  if (/^[A-Z]{2,}$/.test(trimmed)) {
    return false;
  }
  const gate = evaluateLabel(trimmed);
  return gate.accepted;
}

function extractPhrasesFromText(text: string): string[] {
  const phrases: string[] = [];
  const seenInExcerpt = new Set<string>();

  const consider = (rawPhrase: string) => {
    const phrase = trimConnectorEdges(rawPhrase.replace(/\s+/g, " ").trim().replace(/[.,;:!?]+$/, ""));
    if (!acceptablePhrase(phrase)) {
      return;
    }
    const key = normalizeForCompare(phrase);
    if (!key || seenInExcerpt.has(key)) {
      return;
    }
    seenInExcerpt.add(key);
    phrases.push(phrase);
  };

  let capitalMatch;
  while ((capitalMatch = CAPITAL_PHRASE_PATTERN.exec(text)) !== null) {
    consider(capitalMatch[0]);
  }
  CAPITAL_PHRASE_PATTERN.lastIndex = 0;

  let titleCaseMatch;
  while ((titleCaseMatch = TITLE_CASE_SEQUENCE_PATTERN.exec(text)) !== null) {
    if (titleCaseMatch[1]) {
      consider(titleCaseMatch[1]);
    }
  }
  TITLE_CASE_SEQUENCE_PATTERN.lastIndex = 0;

  let quotedMatch;
  while ((quotedMatch = QUOTED_PHRASE_PATTERN.exec(text)) !== null) {
    const content = quotedMatch[1] ?? quotedMatch[2];
    if (content) {
      consider(content);
    }
  }
  QUOTED_PHRASE_PATTERN.lastIndex = 0;

  return phrases;
}

function phraseKey(phrase: string): string {
  return normalizeForCompare(phrase)
    .replace(/^(overview|introduction|principles|foundations)\s+(?:of|to|for)\s+/i, "")
    .replace(/\s+(overview|introduction|principles|foundations)$/i, "")
    .trim();
}

export function extractNounPhraseCandidates(
  evidenceUnits: EvidenceUnit[],
  options: { minMentions?: number; minDocuments?: number } = {}
): NounPhraseCandidate[] {
  const minMentions = options.minMentions ?? MIN_TOTAL_MENTIONS;
  const minDocuments = options.minDocuments ?? MIN_DOCUMENT_COUNT;

  const documentIds = new Set<string>();
  evidenceUnits.forEach((unit) => documentIds.add(unit.sourceItemId));
  const totalDocuments = Math.max(1, documentIds.size);

  const buckets = new Map<string, NounPhraseCandidate>();

  for (const unit of evidenceUnits) {
    const extracted = extractPhrasesFromText(unit.excerpt);
    const headingRoots = unit.headingPath.flatMap((head) => extractPhrasesFromText(head));
    const combined = [...extracted, ...headingRoots];

    for (const phrase of combined) {
      const key = phraseKey(phrase);
      if (!key) {
        continue;
      }
      const existing = buckets.get(key);
      if (existing) {
        existing.totalMentions += 1;
        existing.documentIds.add(unit.sourceItemId);
        existing.evidenceIds.add(unit.id);
        if (unit.kind === "heading" || unit.kind === "title") {
          existing.headingSupport = true;
        }
        continue;
      }

      const gate = evaluateLabel(phrase);
      if (!gate.accepted) {
        continue;
      }
      buckets.set(key, {
        label: gate.cleanedLabel,
        normalizedLabel: key,
        keywords: gate.keywords,
        totalMentions: 1,
        documentIds: new Set([unit.sourceItemId]),
        evidenceIds: new Set([unit.id]),
        headingSupport: unit.kind === "heading" || unit.kind === "title",
        tfIdfScore: 0
      });
    }
  }

  const scored: NounPhraseCandidate[] = [];
  for (const candidate of buckets.values()) {
    if (candidate.totalMentions < minMentions) {
      continue;
    }
    if (candidate.documentIds.size < minDocuments) {
      continue;
    }
    const documentFrequency = Math.max(1, candidate.documentIds.size);
    const inverseDocFrequency = Math.log(1 + totalDocuments / documentFrequency);
    const headingBonus = candidate.headingSupport ? 1.4 : 1;
    const lengthBonus = Math.min(1.5, 1 + candidate.keywords.length * 0.08);
    candidate.tfIdfScore = candidate.totalMentions * inverseDocFrequency * headingBonus * lengthBonus;
    scored.push(candidate);
  }

  scored.sort((left, right) => right.tfIdfScore - left.tfIdfScore || left.label.localeCompare(right.label));
  return scored;
}

export function distinctiveKeywordsForItem(
  itemEvidence: EvidenceUnit[],
  corpusEvidence: EvidenceUnit[]
): string[] {
  const corpusTotals = new Map<string, number>();
  for (const unit of corpusEvidence) {
    for (const token of meaningfulTokens(unit.excerpt)) {
      corpusTotals.set(token, (corpusTotals.get(token) ?? 0) + 1);
    }
  }
  const corpusSize = Math.max(1, corpusEvidence.length);

  const itemCounts = new Map<string, number>();
  for (const unit of itemEvidence) {
    for (const token of meaningfulTokens(unit.excerpt)) {
      itemCounts.set(token, (itemCounts.get(token) ?? 0) + 1);
    }
  }

  const scored: Array<{ token: string; score: number }> = [];
  for (const [token, count] of itemCounts.entries()) {
    const corpusCount = corpusTotals.get(token) ?? 0;
    const inverseDoc = Math.log(1 + corpusSize / Math.max(1, corpusCount));
    scored.push({ token, score: count * inverseDoc });
  }
  scored.sort((left, right) => right.score - left.score || left.token.localeCompare(right.token));
  return scored.slice(0, 12).map((entry) => entry.token);
}
